<?php
#验证登陆！！！
#美化界面 ok
#测试功能 ok
#默认格式！ok
#user -> user_id
#admin administrator
namespace Quiz\Controller;
use Think\Controller;
class AdminController extends AuthController {
    public function index()
    { 

        $data = M('quiz_log')->order('time')->select();
        $this->data = $data;
        $data = M('quiz_problem')->field('content,answer,id')->select();
        $this->data_p = $data;
        $data = M('quiz_answered')->select();
        $this->data_r = $data;
        #var_dump($data);
        $this->display();
    }
    public function addQuiz()
    {
        $m = M('quiz');
        $tmp['quiz'] = I('post.quiz_id');
        $tmp['problem_id'] = I('post.problem_id');
        $m->add($tmp);
        $this->success("添加成功",U('Admin/index'));

    }
    public function addContest()
    {
        $m = M('quiz_msg');
        $tmp['title'] = I('post.title');
        $m->add($tmp);
        $this->success("添加成功",U('Admin/index'));
    }
    public function addProblem()
    {
        $m = M('quiz_problem');
        $tmp['content'] = I('post.content');
        $tmp['answer']  = I('post.answer');
        $tmp['format']  = $_POST['format']?$_POST['format']:NULL;
        $tmp['rank']  = $_POST['rank'];

        $m->add($tmp);
        $this->success("添加成功",U('Admin/index'));
    }
    public function showProblems()
    {
        # code...
    }
}