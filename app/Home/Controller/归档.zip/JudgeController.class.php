<?php
namespace Home\Controller;
use Think\Controller;
class JudgeController extends Controller {
    public function index($id=0)
    {
        $this->display();
    }
}